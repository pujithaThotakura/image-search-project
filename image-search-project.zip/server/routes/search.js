const express = require('express');
const router = express.Router();
const axios = require('axios');
const SearchTerm = require('../models/SearchTerm');

function ensureAuth(req, res, next){ if(req.isAuthenticated && req.isAuthenticated()) return next(); res.status(401).json({error:'unauthenticated'}); }

router.post('/search', ensureAuth, async (req, res) =>{
  try{
    const { term } = req.body;
    if(!term) return res.status(400).json({error:'term required'});
    const userId = (req.user && (req.user.id || req.user.username || req.user.displayName || (req.user.emails && req.user.emails[0] && req.user.emails[0].value))) || 'unknown';
    await SearchTerm.create({ userId, term });
    const url = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(term)}&per_page=30`;
    const resp = await axios.get(url, { headers: { Authorization: `Client-ID ${process.env.UNSPLASH_ACCESS_KEY || ''}` } });
    res.json({ term, total: resp.data.total, results: resp.data.results });
  }catch(err){
    console.error(err.message);
    res.status(500).json({ error: 'server error' });
  }
});

router.get('/history', ensureAuth, async (req, res) => {
  const userId = (req.user && (req.user.id || req.user.username || req.user.displayName || (req.user.emails && req.user.emails[0] && req.user.emails[0].value))) || 'unknown';
  const items = await SearchTerm.find({ userId }).sort({ timestamp: -1 }).limit(50);
  res.json(items);
});

module.exports = router;
