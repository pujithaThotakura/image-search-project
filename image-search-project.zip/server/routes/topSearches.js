const express = require('express');
const router = express.Router();
const SearchTerm = require('../models/SearchTerm');

router.get('/top-searches', async (req, res) =>{
  const agg = await SearchTerm.aggregate([
    { $group: { _id: "$term", count: { $sum: 1 } } },
    { $sort: { count: -1 } },
    { $limit: 5 }
  ]);
  res.json(agg.map(a=>({ term: a._id, count: a.count })));
});

module.exports = router;
