const GoogleStrategy = require('passport-google-oauth20').Strategy;

module.exports = function(passport){
  passport.serializeUser((user, done) => done(null, user));
  passport.deserializeUser((obj, done) => done(null, obj));

  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID || 'GOOGLE_CLIENT_ID',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || 'GOOGLE_CLIENT_SECRET',
    callbackURL: '/auth/google/callback'
  }, (accessToken, refreshToken, profile, done) => {
    // In real app: find or create user in DB
    return done(null, profile);
  }));
};
