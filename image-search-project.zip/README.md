# MERN Image Search & Multi-Select (Scaffold)

This is a scaffold for the assignment. Fill the .env files, install dependencies, and start the server and client.

Server: /server
Client: /client (Vite)

See /server/.env.example for required keys.
