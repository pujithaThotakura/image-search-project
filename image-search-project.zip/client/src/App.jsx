import React, { useState, useEffect } from 'react';
import api from './api';
import SearchBar from './components/SearchBar';
import ImageGrid from './components/ImageGrid';
import TopSearchesBanner from './components/TopSearchesBanner';

export default function App(){
  const [results, setResults] = useState(null);
  const [top, setTop] = useState([]);

  useEffect(()=>{
    async function loadTop(){ try{ const r = await api.get('/api/top-searches'); setTop(r.data); }catch(e){ } }
    loadTop();
  },[]);

  return (
    <div style={{padding:20, fontFamily:'Arial'}}>
      <h2>Image Search (MERN)</h2>
      <div style={{marginBottom:12}}>
        <a href="http://localhost:5000/auth/google">Login with Google</a> | <a href="http://localhost:5000/auth/logout">Logout</a>
      </div>
      <TopSearchesBanner items={top} />
      <SearchBar onResults={setResults} />
      {results && <div style={{marginTop:12}}>You searched for <b>{results.term}</b> — {results.total} results.</div>}
      {results && <ImageGrid images={results.results} />}
    </div>
  )
}
