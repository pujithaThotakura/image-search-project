import React, {useState} from 'react';

export default function ImageGrid({images}){
  const [selected, setSelected] = useState(new Set());

  const toggle = id => {
    const s = new Set(selected);
    if(s.has(id)) s.delete(id); else s.add(id);
    setSelected(s);
  }

  if(!images || images.length===0) return <div style={{marginTop:12}}>No images to show.</div>;

  return (
    <div style={{marginTop:12}}>
      <div>Selected: {selected.size} images</div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8, marginTop:8}}>
        {images.map(img=> (
          <div key={img.id} style={{position:'relative'}}>
            <img src={img.urls.small} alt={img.alt_description||''} style={{width:'100%', height:180, objectFit:'cover', borderRadius:6}} />
            <label style={{position:'absolute', top:8, left:8, background:'rgba(255,255,255,0.9)', padding:'4px 6px', borderRadius:4}}>
              <input type="checkbox" onChange={()=>toggle(img.id)} /> Select
            </label>
          </div>
        ))}
      </div>
    </div>
  )
}
