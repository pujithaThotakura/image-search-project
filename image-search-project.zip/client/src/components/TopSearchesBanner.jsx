import React from 'react';
export default function TopSearchesBanner({items}){
  if(!items || items.length===0) return null;
  return (
    <div style={{background:'#eef', padding:8, borderRadius:6, marginBottom:12}}>
      Top searches: {items.map(it=>`${it.term} (${it.count})`).join(' • ')}
    </div>
  )
}
