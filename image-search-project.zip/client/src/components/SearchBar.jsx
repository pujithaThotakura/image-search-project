import React, {useState} from 'react';
import api from '../api';

export default function SearchBar({onResults}){
  const [q,setQ]=useState('');

  const submit = async e=>{
    e.preventDefault();
    try{
      const r = await api.post('/api/search', { term: q });
      onResults(r.data);
    }catch(err){
      alert(err.response?.data?.error || 'Search failed - make sure you are logged in and server has UNSPLASH_ACCESS_KEY');
    }
  }

  return (
    <form onSubmit={submit} style={{display:'flex', gap:8}}>
      <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search images..." style={{flex:1, padding:8}} />
      <button type="submit">Search</button>
    </form>
  )
}
